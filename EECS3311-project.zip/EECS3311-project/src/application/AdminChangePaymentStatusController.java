package application;

import java.net.URL;

import nonGUI.MaintainCustomerBooking;

import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class AdminChangePaymentStatusController implements Initializable {
	
	String email2;
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		makeFade();
		
	}
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	@FXML
	private Button back;
	
	@FXML
	private Button change;
	
	@FXML
	private TextField firstName;
	
	@FXML
	private TextField lastName;
	
	@FXML
	private TextField email;
	
	@FXML
	private TextField parkingSpace;
	
	public void initData(String user) {
		email2 = user;
	}
	
	public void BackAction() {
		ButtonType YES = new ButtonType("Yes");
		ButtonType NO = new ButtonType("No");
		AlertType type = AlertType.WARNING; 
		Alert alert = new Alert(type, "Are you sure you want to go back? Any unsaved changes will be lost", YES, NO);
		alert.setHeaderText("Confirmation");
		alert.getDialogPane();
		alert.showAndWait().ifPresent(response ->{
			if(response == YES) {
				makeFadeOutBack();
			}
			if(response == NO) {
				
			}
			
		});;
	}
	
	private void makeFadeOutBack() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadBackScene());
		fadeTransition.play();
	}
	
	private void loadBackScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("AdminSignedIn.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			AdminSignedInController controller = loader.getController();
			controller.initData(email2);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void ChangeAction() {
		if(firstName.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("First Name left blank");
            errorAlert.setContentText("Please enter all your details to Change Status");
            errorAlert.showAndWait();
		}
		else if(lastName.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Last Name left blank");
            errorAlert.setContentText("Please enter all your details to Change Status");
            errorAlert.showAndWait();
		}
		else if(email.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Email left blank");
            errorAlert.setContentText("Please enter all your details to Change Status");
            errorAlert.showAndWait();
		}
		else if(parkingSpace.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Parking Space Number left blank");
            errorAlert.setContentText("Please enter all your details to Change Status");
            errorAlert.showAndWait();
		}
		else {
			MaintainCustomerBooking change = new MaintainCustomerBooking(firstName.getText(), lastName.getText(), parkingSpace.getText(), email.getText(), "");
			if(change.change && change.paid) {
				firstName.setText("");
				lastName.setText("");
				email.setText("");
				Alert infoAlert = new Alert(Alert.AlertType.INFORMATION);
				infoAlert.setHeaderText("Payment Status set to 'Paid'");
				infoAlert.setContentText("Change other Payment Status' or hit the Back button to go back to the previous page");
				infoAlert.showAndWait();
			}
//			else if(!change.paid) {
//				Alert errorAlert = new Alert(Alert.AlertType.ERROR);
//				errorAlert.setHeaderText("Customer has not paid for this parking space yet");
//				errorAlert.setContentText("Change other Payment Status' or hit the Back button to go back to the previous page");
//				errorAlert.showAndWait();
//			}
			else if(change.already) {
				Alert errorAlert = new Alert(Alert.AlertType.ERROR);
				errorAlert.setHeaderText("Payment Status is already set to 'Paid'");
				errorAlert.setContentText("Change other Payment Status' or hit the Back button to go back to the previous page");
				errorAlert.showAndWait();
			}
			else {
				Alert errorAlert = new Alert(Alert.AlertType.ERROR);
				errorAlert.setHeaderText("Payment Status not changed");
				errorAlert.setContentText("Please review the details entered below. make sure the Parking Space Number is booked by the Customer. If it is, then the Customer has not yet paid for this booking.");
				errorAlert.showAndWait();
			}
		}
	}
}
