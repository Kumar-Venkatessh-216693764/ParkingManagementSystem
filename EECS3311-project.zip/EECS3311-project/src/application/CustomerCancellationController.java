package application;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import nonGUI.MaintainCustomerBooking;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class CustomerCancellationController implements Initializable {
	
	String email;
	String name;
	int n;
	ArrayList<String> parkingSpacesBooked = new ArrayList<String>();
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		makeFade();
		
	}
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	@FXML
	private Button back;
	
	@FXML
	private Button cancel;
	
	@FXML
	private TextField bookingID;
	
	public void initData(String email2, String name2) {
		email = email2;
		name = name2;
	}
	
	public void BackAction() {
		ButtonType YES = new ButtonType("Yes");
		ButtonType NO = new ButtonType("No");
		AlertType type = AlertType.WARNING; 
		Alert alert = new Alert(type, "Are you sure you want to go back? Any unsaved changes will be lost", YES, NO);
		alert.setHeaderText("Confirmation");
		alert.getDialogPane();
		alert.showAndWait().ifPresent(response ->{
			if(response == YES) {
				makeFadeOutBack();
			}
			if(response == NO) {
				
			}
			
		});;
	}
	
	private void makeFadeOutBack() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadBackScene());
		fadeTransition.play();
	}
	
	private void loadBackScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerSignedIn.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerSignedInController controller = loader.getController();
			controller.initData(email, n, parkingSpacesBooked);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void CancelAction() {
		if(bookingID.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Booking ID not specified");
            errorAlert.setContentText("Please enter the Booking ID to cancel the Booking");
            errorAlert.showAndWait();
		}
		else {
			String[] names = name.split(" ");
			MaintainCustomerBooking cancel = new MaintainCustomerBooking(names[0], names[1], bookingID.getText(), email);
			if(cancel.remove) {
				bookingID.setText("");
				Alert infoAlert = new Alert(Alert.AlertType.INFORMATION);
				infoAlert.setHeaderText("Booking successfully Cancelled");
				infoAlert.setContentText("Cancel more bookings or hit the back button to return to the previous page");
				infoAlert.showAndWait();
			}
			else {
				Alert errorAlert = new Alert(Alert.AlertType.ERROR);
	            errorAlert.setHeaderText("Booking ID incorrect");
	            errorAlert.setContentText("Please recheck the Booking ID you have entered. The Booking has to be valid and should belong to you.");
	            errorAlert.showAndWait();
			}
		}
	}
}
