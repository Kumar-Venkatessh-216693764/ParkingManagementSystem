package application;

import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import nonGUI.MainPaidBookings;

public class CustomerDebitCardController implements Initializable {
	
	ArrayList<Character> checker = new ArrayList<Character>();
	double total;
	ArrayList<String> parkingSpacesAdded = new ArrayList<String>();
	ArrayList<Double> costlist = new ArrayList<Double>();
	String email;
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		makeFade();
		checker.add('1');
		checker.add('2');
		checker.add('3');
		checker.add('4');
		checker.add('5');
		checker.add('6');
		checker.add('7');
		checker.add('8');
		checker.add('9');
		checker.add('0');
	}
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	@FXML
	private Button back;
	
	@FXML
	private Button pay;
	
	@FXML
	private TextField totalAmount;
	
	@FXML
	private TextField name;
	
	@FXML
	private TextField debitCardNumber;
	
	@FXML
	private TextField ccv;
	
	@FXML
	private DatePicker datePicker;
	
	public void initData(double totalAmount2, ArrayList<String> list, String email2, ArrayList<Double> list3) {
		total = totalAmount2;
		totalAmount.setText("" + total);
		parkingSpacesAdded = list;
		email = email2;
		costlist = list3;
	}
	
	public void BackAction() {
		ButtonType YES = new ButtonType("Yes");
		ButtonType NO = new ButtonType("No");
		AlertType type = AlertType.WARNING; 
		Alert alert = new Alert(type, "Are you sure you want to go back? Any unsaved changes will be lost", YES, NO);
		alert.setHeaderText("Confirmation");
		alert.getDialogPane();
		alert.showAndWait().ifPresent(response ->{
			if(response == YES) {
				makeFadeOutBack();
			}
			if(response == NO) {
				
			}
			
		});;
	}
	
	private void makeFadeOutBack() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadBackScene());
		fadeTransition.play();
	}
	
	private void loadBackScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerPaymentTypes.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerPaymentTypesController controller = loader.getController();
			controller.initData(total, parkingSpacesAdded, email, costlist);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void PayAction() {
		int a = 0;
		int b = 0;
		if(name.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Name not specified");
            errorAlert.setContentText("Please enter all your Credit Card details to pay");
            errorAlert.showAndWait();
		}
		else if(debitCardNumber.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Credit Card Number not specified");
            errorAlert.setContentText("Please enter all your Credit Card details to pay");
            errorAlert.showAndWait();
		}
		else if(ccv.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("CCV not specified");
            errorAlert.setContentText("Please enter all your Credit Card details to pay");
            errorAlert.showAndWait();
		}
		else if(datePicker.getValue() == null) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Expiry Date not specified");
            errorAlert.setContentText("Please enter all your Credit Card details to pay");
            errorAlert.showAndWait();
		}
		else {
			for(int i = 0; i < debitCardNumber.getText().length(); i++) {
				if(!checker.contains(debitCardNumber.getText().charAt(i))) {
					a = 1;
					i = debitCardNumber.getText().length();
					Alert errorAlert = new Alert(Alert.AlertType.ERROR);
		            errorAlert.setHeaderText("Invalid Credit Card Number specified");
		            errorAlert.setContentText("Please enter a valid Credit Card Number to pay");
		            errorAlert.showAndWait();
				}
			}
			for(int j = 0; j < ccv.getText().length(); j++) {
				if(!checker.contains(ccv.getText().charAt(j))) {
					b = 1;
					j = ccv.getText().length();
					Alert errorAlert = new Alert(Alert.AlertType.ERROR);
		            errorAlert.setHeaderText("Invalid CCV specified");
		            errorAlert.setContentText("Please enter a valid CCV to pay");
		            errorAlert.showAndWait();
				}
			}
			if(a == 0 && b == 0) {
				if(debitCardNumber.getText().equals("0")) {
					Alert errorAlert = new Alert(Alert.AlertType.ERROR);
		            errorAlert.setHeaderText("Invalid Credit Card Number specified");
		            errorAlert.setContentText("Please enter a valid Credit Card Number to pay");
		            errorAlert.showAndWait();
				}
				else if(ccv.getText().equals("0")) {
					Alert errorAlert = new Alert(Alert.AlertType.ERROR);
		            errorAlert.setHeaderText("Invalid CCV specified");
		            errorAlert.setContentText("Please enter a valid CCV to pay");
		            errorAlert.showAndWait();
				}
				else {
					int n1 = Integer.parseInt(ccv.getText());
					String n2 = debitCardNumber.getText();
					if(n1 >= 100 && n1 <= 999 && n2.length() == 16) {
						LocalDateTime localTime = LocalDateTime.now();
						LocalDate localDay = LocalDate.now();
						DateTimeFormatter curTime = DateTimeFormatter.ofPattern("hh:mm");
						DateTimeFormatter curDay = DateTimeFormatter.ofPattern("MM-dd-yyyy");
//						System.out.println(curTime.format(localTime));
						LocalDate date = datePicker.getValue();
						String formattedDate = date.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));
						if(localDay.isAfter(date)) {
							Alert errorAlert = new Alert(Alert.AlertType.ERROR);
				            errorAlert.setHeaderText("Card Expired");
				            errorAlert.setContentText("Please enter correct details to Pay");
				            errorAlert.showAndWait();
						}
						else {
//							System.out.println(date.toString());
//							System.out.println(formattedDate);
							MainPaidBookings pay = new MainPaidBookings(parkingSpacesAdded, email, curTime.format(localTime));
							Alert payAlert = new Alert(Alert.AlertType.INFORMATION);
							payAlert.setHeaderText("Payment Successfull");
							payAlert.setContentText("Your payment has been processed and have successfully paid for your parking spots\n"
									+ "Hit the Back button to go back to the previous page");
							payAlert.showAndWait();
						}
					}
					else {
						if(n2.length() == 16) {
							Alert errorAlert = new Alert(Alert.AlertType.ERROR);
				            errorAlert.setHeaderText("Incorrect CCV specified");
				            errorAlert.setContentText("Please enter correct details to Pay");
				            errorAlert.showAndWait();
						}
						else {
							Alert errorAlert = new Alert(Alert.AlertType.ERROR);
				            errorAlert.setHeaderText("Incorrect Debit Card Number specified");
				            errorAlert.setContentText("Please enter correct details to Pay");
				            errorAlert.showAndWait();
						}
					}
				}
			}
		}
	}

}
