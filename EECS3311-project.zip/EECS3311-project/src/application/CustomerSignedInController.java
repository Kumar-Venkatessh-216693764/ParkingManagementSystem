package application;

import java.net.URL;

import nonGUI.MaintainCustomerLogin;

import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class CustomerSignedInController implements Initializable {
	
	int nBookings;
	ArrayList<String> parkingSpacesBooked = new ArrayList<String>();
	ArrayList<Double> costlist = new ArrayList<Double>();
	String firstname;
	String lastname;
	String email;
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		makeFade();
		
	}
	
	private void initName() {
		MaintainCustomerLogin check = new MaintainCustomerLogin(email);
		firstname = check.firstname;
		lastname = check.lastname;
		name.setText(firstname + " " + lastname);
	}
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	@FXML
	private Button signOut;
	
	@FXML
	private Button book;
	
	@FXML
	private Button cancel;
	
	@FXML
	private Button pay;
	
	@FXML
	private Button viewBooking;
	
	@FXML
	private Label name;
	
	public void initData(String user, int bookings, ArrayList list) {
		email = user;
		nBookings = bookings;
		parkingSpacesBooked = list;
		initName();
	}
	
	public void SignOutAction() {
		ButtonType YES = new ButtonType("Yes");
		ButtonType NO = new ButtonType("No");
		AlertType type = AlertType.WARNING; 
		Alert alert = new Alert(type, "Are you sure you want to Sign Out?", YES, NO);
		alert.setHeaderText("Confirmation");
		alert.getDialogPane();
		alert.showAndWait().ifPresent(response ->{
			if(response == YES) {
				makeFadeOutSignOut();
			}
			if(response == NO) {
				
			}
			
		});;
	}
	
	private void makeFadeOutSignOut() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadSignOutScene());
		fadeTransition.play();
	}
	
	private void loadSignOutScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerLogin.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerLoginController controller = loader.getController();
//			controller.initData(textArea2, textField2, this.fileContent, this.timeSignature, this.tempo, this.save);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void BookAction() {
		makeFadeOutBook();
	}
	
	private void makeFadeOutBook() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadBookScene());
		fadeTransition.play();
	}
	
	private void loadBookScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerBooking.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerBookingController controller = loader.getController();
			controller.initData(name.getText(), nBookings, parkingSpacesBooked, email);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void CancelAction() {
		makeFadeOutCancel();
	}
	
	private void makeFadeOutCancel() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadCancelScene());
		fadeTransition.play();
	}
	
	private void loadCancelScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerCancellation.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerCancellationController controller = loader.getController();
			controller.initData(email, name.getText());
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void PayAction() {
		makeFadeOutPay();
	}
	
	private void makeFadeOutPay() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadPayScene());
		fadeTransition.play();
	}
	
	private void loadPayScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerPayment.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerPaymentController controller = loader.getController();
			controller.initData(0, parkingSpacesBooked, email, costlist);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void ViewBookingsAction() {
		makeFadeOutViewBooking();
	}
	
	private void makeFadeOutViewBooking() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadViewBookingScene());
		fadeTransition.play();
	}
	
	private void loadViewBookingScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerViewBooking.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerViewBookingController controller = loader.getController();
			controller.initData(email);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
