package application;

import java.net.URL;

import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import nonGUI.MaintainAdminLogin;

public class AdminLoginController implements Initializable {
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		makeFade();
		Image mainUser = new Image("application/Admin.png");
		Image mainLogin = new Image("application/UserLogin.png");
		Image mainPass = new Image("application/Password.png");
		main.setImage(mainUser);
		user.setImage(mainLogin);
		pass.setImage(mainPass);
		
	}
	
	@FXML
	private Button signIn;
	
	@FXML
	private Button back;
	
	@FXML
	private TextField email;
	
	@FXML
	private TextField password;
	
	@FXML
	private ImageView main;
	
	@FXML
	private ImageView user;
	
	@FXML
	private ImageView pass;
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	public void SignInAction() {
		if(email.getText().equals("") && password.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("No Login Credentials");
            errorAlert.setContentText("Please enter your Login details to Sign in");
            errorAlert.showAndWait();
		}
		else if(email.getText().equals("") && !password.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("No Email given");
            errorAlert.setContentText("Please enter your Email to Sign in");
            errorAlert.showAndWait();
		}
		else if(!email.getText().equals("") && password.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("No Password given");
            errorAlert.setContentText("Please enter your Password to Sign in");
            errorAlert.showAndWait();
		}
		else {
			MaintainAdminLogin login = new MaintainAdminLogin(email.getText(), password.getText());
			if(login.signIn) {
				makeFadeOutSignIn();
			}
			else {
				Alert errorAlert = new Alert(Alert.AlertType.ERROR);
	            errorAlert.setHeaderText("Incorrect Login Credentials");
	            errorAlert.setContentText("Please recheck the information entered. If you are a new user, please hit the Register button.");
	            errorAlert.showAndWait();
			}
		}
	}
	
	private void makeFadeOutSignIn() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadAdminSignedInScene());
		fadeTransition.play();
	}
	
	private void loadAdminSignedInScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("AdminSignedIn.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			AdminSignedInController controller = loader.getController();
			controller.initData(email.getText());
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void BackAction() {
		ButtonType YES = new ButtonType("Yes");
		ButtonType NO = new ButtonType("No");
		AlertType type = AlertType.WARNING; 
		Alert alert = new Alert(type, "Would you like to go back?", YES, NO);
		alert.setHeaderText("Confirmation");
		alert.getDialogPane();
		alert.showAndWait().ifPresent(response ->{
			if(response == YES) {
				makeFadeOutBack();
			}
			if(response == NO) {
				
			}
			
		});;
	}
	
	private void makeFadeOutBack() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadBackScene());
		fadeTransition.play();
	}
	
	private void loadBackScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("Login.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			LoginController controller = loader.getController();
//			controller.initData(textArea2, textField2, this.fileContent, this.timeSignature, this.tempo, this.save);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}

