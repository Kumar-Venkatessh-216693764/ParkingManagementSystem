package application;

import java.net.URL;

import nonGUI.MaintainCustomerLogin;

import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class CustomerRegisterController implements Initializable {
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		makeFade();
		
	}
	
	@FXML
	private Button back;
	
	@FXML
	private Button register;
	
	@FXML
	private TextField firstName;
	
	@FXML
	private TextField lastName;
	
	@FXML
	private TextField email;
	
	@FXML
	private TextField password;
	
	@FXML
	private TextField confirmPassword;
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	public void BackAction() {
		ButtonType YES = new ButtonType("Yes");
		ButtonType NO = new ButtonType("No");
		AlertType type = AlertType.WARNING; 
		Alert alert = new Alert(type, "Would you like to go back?", YES, NO);
		alert.setHeaderText("Confirmation");
		alert.getDialogPane();
		alert.showAndWait().ifPresent(response ->{
			if(response == YES) {
				makeFadeOutBack();
			}
			if(response == NO) {
				
			}
			
		});;
	}
	
	private void makeFadeOutBack() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadBackScene());
		fadeTransition.play();
	}
	
	private void loadBackScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerLogin.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerLoginController controller = loader.getController();
//			controller.initData(textArea2, textField2, this.fileContent, this.timeSignature, this.tempo, this.save);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void RegisterAction() {
		if(firstName.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("First Name left blank");
            errorAlert.setContentText("Please enter all your details to Register");
            errorAlert.showAndWait();
		}
		else if(lastName.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Last Name left blank");
            errorAlert.setContentText("Please enter all your details to Register");
            errorAlert.showAndWait();
		}
		else if(email.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Email left blank");
            errorAlert.setContentText("Please enter all your details to Register");
            errorAlert.showAndWait();
		}
		else if(password.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Password left blank");
            errorAlert.setContentText("Please enter all your details to Register");
            errorAlert.showAndWait();
		}
		else {
			if(!password.getText().equals(confirmPassword.getText())) {
				Alert errorAlert = new Alert(Alert.AlertType.ERROR);
	            errorAlert.setHeaderText("Passwords do not match");
	            errorAlert.setContentText("Please enter the correct Password to both the field 'Password' and 'Confirm Passowrd'");
	            errorAlert.showAndWait();
			}
			else {
				MaintainCustomerLogin login = new MaintainCustomerLogin(firstName.getText(), lastName.getText(), "", email.getText(), password.getText());
				Alert infoAlert = new Alert(Alert.AlertType.INFORMATION);
				infoAlert.setHeaderText("Registration Successful");
				infoAlert.setContentText("You will now be taken back to the Login Page where you can Sign In with your registration details");
				infoAlert.showAndWait();
				makeFadeOutRegister();
			}
		}
	}
	
	private void makeFadeOutRegister() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadRegisteredScene());
		fadeTransition.play();
	}
	
	private void loadRegisteredScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerLogin.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerLoginController controller = loader.getController();
//			controller.initData(textArea2, textField2, this.fileContent, this.timeSignature, this.tempo, this.save);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
