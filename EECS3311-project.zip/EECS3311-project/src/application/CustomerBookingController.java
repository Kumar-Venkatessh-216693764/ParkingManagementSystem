package application;

import java.net.URL;

import nonGUI.MaintainCustomerBooking;

import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class CustomerBookingController implements Initializable {
	
	ArrayList<Character> checker = new ArrayList<Character>();
	ArrayList<String> parkingSpacesBooked = new ArrayList<String>();
	int nBookings = 0;
	String name;
	int bookingID = 0;
	String email;
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		makeFade();
		
	}
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	@FXML
	private Button back;
	
	@FXML
	private Button addBooking;
	
	@FXML
	private TextField parkingSpace;
	
	@FXML
	private TextField hours;
	
	@FXML
	private TextField mins;
	
	@FXML
	private TextField licence;
	
	public void initData(String user, int bookings, ArrayList list, String email2) {
		name = user;
		nBookings = bookings;
		parkingSpacesBooked = list;
		email = email2;
	}
	
	public void BackAction() {
		ButtonType YES = new ButtonType("Yes");
		ButtonType NO = new ButtonType("No");
		AlertType type = AlertType.WARNING; 
		Alert alert = new Alert(type, "Are you sure you want to go back? Any unsaved changes will be lost", YES, NO);
		alert.setHeaderText("Confirmation");
		alert.getDialogPane();
		alert.showAndWait().ifPresent(response ->{
			if(response == YES) {
				makeFadeOutBack();
			}
			if(response == NO) {
				
			}
			
		});;
	}
	
	private void makeFadeOutBack() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadBackScene());
		fadeTransition.play();
	}
	
	private void loadBackScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerSignedIn.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerSignedInController controller = loader.getController();
			controller.initData(email, nBookings, parkingSpacesBooked);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void AddBookingAction() {
		if(nBookings >= 3) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("3 Bookings made");
            errorAlert.setContentText("You have already made the maximum number of allowed bookings per customer (3)\n"
            		+ "Please hit the back button to return to the previous page");
            errorAlert.showAndWait();
		}
		else {
			checker.add('1');
			checker.add('2');
			checker.add('3');
			checker.add('4');
			checker.add('5');
			checker.add('6');
			checker.add('7');
			checker.add('8');
			checker.add('9');
			checker.add('0');
			int a = 0;
			int b = 0;
			if(parkingSpace.getText().equals("")) {
				Alert errorAlert = new Alert(Alert.AlertType.ERROR);
	            errorAlert.setHeaderText("Parking Space Number not specified");
	            errorAlert.setContentText("Please enter all the details to Add a Booking");
	            errorAlert.showAndWait();
			}
			else if(hours.getText().equals("")) {
				Alert errorAlert = new Alert(Alert.AlertType.ERROR);
	            errorAlert.setHeaderText("Hours not specified for Booking time");
	            errorAlert.setContentText("Please enter all the details to Add a Booking");
	            errorAlert.showAndWait();
			}
			else if(mins.getText().equals("")) {
				Alert errorAlert = new Alert(Alert.AlertType.ERROR);
	            errorAlert.setHeaderText("Minutes not specified for Booking time");
	            errorAlert.setContentText("Please enter all the details to Add a Booking");
	            errorAlert.showAndWait();
			}
			else if(licence.getText().equals("")) {
				Alert errorAlert = new Alert(Alert.AlertType.ERROR);
	            errorAlert.setHeaderText("Licence Plate Number Blank");
	            errorAlert.setContentText("Please enter all the details to Add a Booking");
	            errorAlert.showAndWait();
			}
			else {
				for(int i = 0; i < hours.getText().length(); i++) {
					if(!checker.contains(hours.getText().charAt(i))) {
						a = 1;
						i = hours.getText().length();
						Alert errorAlert = new Alert(Alert.AlertType.ERROR);
			            errorAlert.setHeaderText("Invalid Booking time specified");
			            errorAlert.setContentText("Invalid hours specified\n"
			            		+ "Please enter a valid number");
			            errorAlert.showAndWait();
					}
				}
				for(int j = 0; j < mins.getText().length(); j++) {
					if(!checker.contains(mins.getText().charAt(j))) {
						b = 1;
						j = mins.getText().length();
						Alert errorAlert = new Alert(Alert.AlertType.ERROR);
			            errorAlert.setHeaderText("Invalid Booking time specified");
			            errorAlert.setContentText("Invalid minutes specified\n"
			            		+ "Please enter a valid number");
			            errorAlert.showAndWait();
					}
				}
				if(a == 0 && b == 0) {
					int hr = Integer.parseInt(hours.getText());
					int min = Integer.parseInt(mins.getText());
					if(hr == 0 && min == 0) {
						Alert errorAlert = new Alert(Alert.AlertType.ERROR);
			            errorAlert.setHeaderText("Invalid Booking time specified");
			            errorAlert.setContentText("Booking time cannot be 0 hours and 0 minutes");
			            errorAlert.showAndWait();
					}
					else if(min < 0 || min > 59){
						Alert errorAlert = new Alert(Alert.AlertType.ERROR);
			            errorAlert.setHeaderText("Invalid Booking time specified");
			            errorAlert.setContentText("Invalid minutes specified\n"
			            		+ "Minutes cannot be less than 0 or greater than 59");
			            errorAlert.showAndWait();
					}
					else if(hr < 0) {
						Alert errorAlert = new Alert(Alert.AlertType.ERROR);
			            errorAlert.setHeaderText("Invalid Booking time specified");
			            errorAlert.setContentText("Invalid hours specified\n"
			            		+ "Hours cannot be less than 0");
			            errorAlert.showAndWait();
					}
					else if(a == 0 && b == 0) {
						int c = 0;
						for(int k = 0; k < parkingSpacesBooked.size(); k++) {
							if(parkingSpacesBooked.get(k).equals(parkingSpace.getText())) {
								c = 1;
								k = parkingSpacesBooked.size();
								Alert errorAlert = new Alert(Alert.AlertType.ERROR);
					            errorAlert.setHeaderText("Parking Occupied");
					            errorAlert.setContentText("The entered Parking Space Number is already occupied\n"
					            		+ "Please choose another Parking Space to book");
					            errorAlert.showAndWait();
							}
						}
						if(c == 0) {
							String[] names = name.split(" ");
							MaintainCustomerBooking book = new MaintainCustomerBooking(names[0], names[1], parkingSpace.getText(), licence.getText(), hours.getText(), mins.getText(), email);
							if(book.booked) {
								nBookings = nBookings + 1;
								bookingID++;
								parkingSpacesBooked.add(parkingSpace.getText());
								parkingSpace.setText("");
								Alert errorAlert = new Alert(Alert.AlertType.INFORMATION);
					            errorAlert.setHeaderText("Booking successfully added");
					            errorAlert.setContentText("You are allowed to add a maximum of 3 bookings\n"
					            		+ "You booking ID is " + book.currentId + "\n"
					            		+ "Add more bookings if you wish and hit the back button when done to go back to the previous page");
					            errorAlert.showAndWait();
							}
							else if(!book.forth) {
								Alert errorAlert = new Alert(Alert.AlertType.ERROR);
					            errorAlert.setHeaderText("Parking Invalid");
					            errorAlert.setContentText("Please enter a Parking Space Number that is present in the system");
					            errorAlert.showAndWait();
							}
							else if(book.duplicate) {
								Alert errorAlert = new Alert(Alert.AlertType.ERROR);
					            errorAlert.setHeaderText("Parking Occupied");
					            errorAlert.setContentText("The entered Parking Space Number is already occupied\n"
					            		+ "Please choose another Parking Space to book");
					            errorAlert.showAndWait();
							}
							else if(book.many) {
								Alert errorAlert = new Alert(Alert.AlertType.ERROR);
					            errorAlert.setHeaderText("3 Bookings made");
					            errorAlert.setContentText("You have already made the maximum number of allowed bookings per customer (3)\n"
					            		+ "Please hit the back button to return to the previous page");
					            errorAlert.showAndWait();
							}
						}
					}
				}
			}
		}
	}
}
