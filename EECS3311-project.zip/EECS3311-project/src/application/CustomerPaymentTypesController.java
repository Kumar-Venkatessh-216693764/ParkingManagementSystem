package application;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class CustomerPaymentTypesController implements Initializable {
	
	ArrayList<Character> checker = new ArrayList<Character>();
	double total;
	ArrayList<String> parkingSpacesAdded = new ArrayList<String>();
	ArrayList<Double> costlist = new ArrayList<Double>();
	String email;
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		makeFade();
		checker.add('1');
		checker.add('2');
		checker.add('3');
		checker.add('4');
		checker.add('5');
		checker.add('6');
		checker.add('7');
		checker.add('8');
		checker.add('9');
		checker.add('0');
	}
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	@FXML
	private Button back;
	
	@FXML
	private Button paypal;
	
	@FXML
	private Button credit;
	
	@FXML
	private Button debit;
	
	@FXML
	private Button eTransfer;
	
	public void initData(double totalAmount, ArrayList<String> list, String email2, ArrayList<Double> list3) {
		total = totalAmount;
		parkingSpacesAdded = list;
		email = email2;
		costlist = list3;
	}
	
	public void BackAction() {
		makeFadeOutBack();
	}
	
	private void makeFadeOutBack() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadBackScene());
		fadeTransition.play();
	}
	
	private void loadBackScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerPayment.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerPaymentController controller = loader.getController();
			controller.initData(total, parkingSpacesAdded, email, costlist);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
//	public void PaypalAction() {
//		makeFadeOutPaypal();
//	}
//	
//	private void makeFadeOutPaypal() {
//		FadeTransition fadeTransition = new FadeTransition();
//		fadeTransition.setDuration(Duration.millis(500));
//		fadeTransition.setNode(rootPane);
//		fadeTransition.setFromValue(1);
//		fadeTransition.setToValue(0);
//		fadeTransition.setOnFinished(event -> loadPaypalScene());
//		fadeTransition.play();
//	}
//	
//	private void loadPaypalScene() {
//		try {
//			FXMLLoader loader = new FXMLLoader();
//			loader.setLocation(getClass().getResource("CustomerPaypal.fxml"));
//			Parent secondView = loader.load();
//			Scene newScene = new Scene(secondView);
//			CustomerPaypalController controller = loader.getController();
//			controller.initData(total, parkingSpacesAdded);
//			Stage curStage = (Stage) rootPane.getScene().getWindow();
//			curStage.setScene(newScene);
//			curStage.show();
//		} catch(Exception e) {
//			e.printStackTrace();
//		}
//	}
//	
	public void CreditAction() {
		makeFadeOutCredit();
	}
	
	private void makeFadeOutCredit() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadCreditScene());
		fadeTransition.play();
	}
	
	private void loadCreditScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerCreditCard.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerCreditCardController controller = loader.getController();
			controller.initData(total, parkingSpacesAdded, email, costlist);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void DebitAction() {
		makeFadeOutDebit();
	}
	
	private void makeFadeOutDebit() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadDebitScene());
		fadeTransition.play();
	}
	
	private void loadDebitScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerDebitCard.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerDebitCardController controller = loader.getController();
			controller.initData(total, parkingSpacesAdded, email, costlist);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

//	public void ETransferAction() {
//		makeFadeOutET();
//	}
//	
//	private void makeFadeOutET() {
//		FadeTransition fadeTransition = new FadeTransition();
//		fadeTransition.setDuration(Duration.millis(500));
//		fadeTransition.setNode(rootPane);
//		fadeTransition.setFromValue(1);
//		fadeTransition.setToValue(0);
//		fadeTransition.setOnFinished(event -> loadETScene());
//		fadeTransition.play();
//	}
//	
//	private void loadETScene() {
//		try {
//			FXMLLoader loader = new FXMLLoader();
//			loader.setLocation(getClass().getResource("CustomerETransfer.fxml"));
//			Parent secondView = loader.load();
//			Scene newScene = new Scene(secondView);
//			CustomerETransferController controller = loader.getController();
//			controller.initData(total, parkingSpacesAdded);
//			Stage curStage = (Stage) rootPane.getScene().getWindow();
//			curStage.setScene(newScene);
//			curStage.show();
//		} catch(Exception e) {
//			e.printStackTrace();
//		}
//	}
}
