package application;

import java.net.URL;

import nonGUI.MaintainCustomerBooking;

import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class CustomerPaymentController implements Initializable {
	
	ArrayList<Character> checker = new ArrayList<Character>();
	int total = 0;
	ArrayList<String> parkingSpacesAdded = new ArrayList<String>();
	ArrayList<String> parkingSpacesAdded2 = new ArrayList<String>();
	ArrayList<Double> costlist = new ArrayList<Double>();
	String email;
	double cost;
	int hrs;
	int mins;
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		makeFade();
		checker.add('1');
		checker.add('2');
		checker.add('3');
		checker.add('4');
		checker.add('5');
		checker.add('6');
		checker.add('7');
		checker.add('8');
		checker.add('9');
		checker.add('0');
	}
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	@FXML
	private Button back;
	
	@FXML
	private Button add;
	
	@FXML
	private Button pay;
	
	@FXML
	private TextField parkingSpace;
	
	@FXML
	private TextField totalAmount;
	
	@FXML
	private ListView list;
	
	public void initData(double totalAmount2, ArrayList<String> list2, String email2, ArrayList<Double> list3) {
		cost = totalAmount2;
		totalAmount.setText("" + cost);
		parkingSpacesAdded = list2;
		email = email2;
		costlist = list3;
		for(int i = 0; i < parkingSpacesAdded.size(); i++) {
			list.getItems().add("Parking Space Number: " + parkingSpacesAdded.get(i) + ", Cost: - $" + costlist.get(i));
		}
	}
	
	public void BackAction() {
		ButtonType YES = new ButtonType("Yes");
		ButtonType NO = new ButtonType("No");
		AlertType type = AlertType.WARNING; 
		Alert alert = new Alert(type, "Are you sure you want to go back? Any unsaved changes will be lost", YES, NO);
		alert.setHeaderText("Confirmation");
		alert.getDialogPane();
		alert.showAndWait().ifPresent(response ->{
			if(response == YES) {
				makeFadeOutBack();
			}
			if(response == NO) {
				
			}
			
		});;
	}
	
	private void makeFadeOutBack() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadBackScene());
		fadeTransition.play();
	}
	
	private void loadBackScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerSignedIn.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerSignedInController controller = loader.getController();
			controller.initData(email, 0, parkingSpacesAdded2);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void AddAction() {
		if(parkingSpace.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Parking Space Number not specified");
            errorAlert.setContentText("Please enter a valid Parking Space Number to pay for");
            errorAlert.showAndWait();
		}
		else {
			int a = 0;
			for(int i = 0; i < parkingSpace.getText().length(); i++) {
				if(!checker.contains(parkingSpace.getText().charAt(i))) {
					a = 1;
					i = parkingSpace.getText().length();
					Alert errorAlert = new Alert(Alert.AlertType.ERROR);
		            errorAlert.setHeaderText("Invalid Parking Space specified");
		            errorAlert.setContentText("Please enter a valid Parking Space Number to pay for");
		            errorAlert.showAndWait();
				}
			}
			if(a == 0) {
				int n = Integer.parseInt(parkingSpace.getText());
				if(n == 0) {
					Alert errorAlert = new Alert(Alert.AlertType.ERROR);
		            errorAlert.setHeaderText("Invalid Parking Space specified");
		            errorAlert.setContentText("Please enter a valid Parking Space Number to pay for");
		            errorAlert.showAndWait();
				}
				else {
					int c = 0;
					for(int k = 0; k < parkingSpacesAdded.size(); k++) {
						if(parkingSpacesAdded.get(k).equals(parkingSpace.getText())) {
							c = 1;
							k = parkingSpacesAdded.size();
							Alert errorAlert = new Alert(Alert.AlertType.ERROR);
				            errorAlert.setHeaderText("Parking already added");
				            errorAlert.setContentText("Please enter another Parking Space Number to pay for or hit the Pay button to proceed to Payment");
				            errorAlert.showAndWait();
						}
					}
					if(c == 0) {
						MaintainCustomerBooking book = new MaintainCustomerBooking(parkingSpace.getText(), email, "");
						if(book.approved) {
							parkingSpacesAdded.add(parkingSpace.getText());
							hrs = Integer.parseInt(book.hours);
							mins = Integer.parseInt(book.mins);
							cost = cost + (2 * hrs) + (0.033 * mins);
							costlist.add(cost);
							list.getItems().add("Parking Space Number: " + parkingSpace.getText() + ", Cost: - $" + ((2 * hrs) + (0.033 * mins)));
							totalAmount.setText("$" + cost);	
						}
						else if(book.unapproved) {
							Alert errorAlert = new Alert(Alert.AlertType.ERROR);
				            errorAlert.setHeaderText("Parking not approved by Authority");
				            errorAlert.setContentText("Please enter another Parking Space Number to pay for or hit the Pay button to proceed to Payment");
				            errorAlert.showAndWait();
						}
						else if(book.someoneelse) {
							Alert errorAlert = new Alert(Alert.AlertType.ERROR);
				            errorAlert.setHeaderText("Parking belongs to another Person");
				            errorAlert.setContentText("Please enter another Parking Space Number to pay for or hit the Pay button to proceed to Payment");
				            errorAlert.showAndWait();
						}
						else if(book.notexist) {
							Alert errorAlert = new Alert(Alert.AlertType.ERROR);
				            errorAlert.setHeaderText("Parking is not booked");
				            errorAlert.setContentText("Please enter another Parking Space Number to pay for or hit the Pay button to proceed to Payment");
				            errorAlert.showAndWait();
						}
					}
				}
			}
		}
	}
	
	public void PayAction() {
		if(list.getItems().size() == 0) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("No Parking Chosen");
            errorAlert.setContentText("Please enter a Parking Space Number to pay for");
            errorAlert.showAndWait();
		}
		else {
			makeFadeOutPay();
		}
	}
	
	private void makeFadeOutPay() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadPayScene());
		fadeTransition.play();
	}
	
	private void loadPayScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerPaymentTypes.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerPaymentTypesController controller = loader.getController();
			controller.initData(cost, parkingSpacesAdded, email, costlist);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
