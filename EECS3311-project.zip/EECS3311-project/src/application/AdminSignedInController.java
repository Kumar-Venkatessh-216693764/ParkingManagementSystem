package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import nonGUI.MaintainAdminLogin;
import nonGUI.MaintainAuthorityLogin;

public class AdminSignedInController implements Initializable {
	
	String firstname;
	String lastname;
	String email;
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		makeFade();
		
	}
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	private void initName() {
		MaintainAdminLogin check = new MaintainAdminLogin(email, "", "");
		firstname = check.firstname;
		lastname = check.lastname;
		userName.setText(firstname + " " + lastname);
	}
	
	@FXML
	private Button signOut;
	
	@FXML
	private Button add;
	
	@FXML
	private Button remove;
	
	@FXML
	private Button change;
	
	@FXML
	private Label userName;
	
	public void initData(String user) {
		email = user;
		initName();
	}
	
	public void SignOutAction() {
		ButtonType YES = new ButtonType("Yes");
		ButtonType NO = new ButtonType("No");
		AlertType type = AlertType.WARNING; 
		Alert alert = new Alert(type, "Are you sure you want to Sign Out?", YES, NO);
		alert.setHeaderText("Confirmation");
		alert.getDialogPane();
		alert.showAndWait().ifPresent(response ->{
			if(response == YES) {
				makeFadeOutSignOut();
			}
			if(response == NO) {
				
			}
			
		});;
	}
	
	private void makeFadeOutSignOut() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadSignOutScene());
		fadeTransition.play();
	}
	
	private void loadSignOutScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("AdminLogin.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			AdminLoginController controller = loader.getController();
//			controller.initData(textArea2, textField2, this.fileContent, this.timeSignature, this.tempo, this.save);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void AddOfficerAction() {
		makeFadeOutAddOfficer();
	}
	
	private void makeFadeOutAddOfficer() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadAddOfficer());
		fadeTransition.play();
	}
	
	private void loadAddOfficer() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("AdminAddOfficer.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			AdminAddOfficerController controller = loader.getController();
			controller.initData(email);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void RemoveOfficerAction() {
		makeFadeOutRemoveOfficer();
	}
	
	private void makeFadeOutRemoveOfficer() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadRemoveOfficer());
		fadeTransition.play();
	}
	
	private void loadRemoveOfficer() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("AdminRemoveOfficer.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			AdminRemoveOfficerController controller = loader.getController();
			controller.initData(email);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void ChangePaymentStatusAction() {
		makeFadeOutChangePaymentStatus();
	}
	
	private void makeFadeOutChangePaymentStatus() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadChangePaymentStatus());
		fadeTransition.play();
	}

	private void loadChangePaymentStatus() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("AdminChangePaymentStatus.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			AdminChangePaymentStatusController controller = loader.getController();
			controller.initData(email);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
