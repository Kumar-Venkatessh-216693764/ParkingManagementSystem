package application;

import java.net.URL;

import nonGUI.MaintainParkingSpace;

import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class AuthorityAddParkingController implements Initializable {
	
	ArrayList<String> parkingSpacesAdded = new ArrayList<String>();
	ArrayList<Character> checker = new ArrayList<Character>();
	String email;
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		makeFade();
		checker.add('1');
		checker.add('2');
		checker.add('3');
		checker.add('4');
		checker.add('5');
		checker.add('6');
		checker.add('7');
		checker.add('8');
		checker.add('9');
		checker.add('0');
	}
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	@FXML
	private Button back;
	
	@FXML
	private Button add;
	
	@FXML
	private TextField parkingSpaceNumber;
	
	public void initData(String email2) {
		email = email2;
	}
	
	public void BackAction() {
		ButtonType YES = new ButtonType("Yes");
		ButtonType NO = new ButtonType("No");
		AlertType type = AlertType.WARNING; 
		Alert alert = new Alert(type, "Are you sure you want to go back? Any unsaved changes will be lost", YES, NO);
		alert.setHeaderText("Confirmation");
		alert.getDialogPane();
		alert.showAndWait().ifPresent(response ->{
			if(response == YES) {
				for(int i = 0; i < parkingSpacesAdded.size() - 1; i++) {
					for(int j = i + 1; j < parkingSpacesAdded.size(); j++) {
						if(parkingSpacesAdded.get(i) == parkingSpacesAdded.get(j)) {
							parkingSpacesAdded.remove(j);
						}
					}
				}
				makeFadeOutBack();
			}
			if(response == NO) {
				
			}
			
		});;
	}
	
	private void makeFadeOutBack() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadBackScene());
		fadeTransition.play();
	}
	
	private void loadBackScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("AuthorityManageParking.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			AuthorityManageParkingController controller = loader.getController();
			controller.initData(email);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void AddAction() {
		if(parkingSpaceNumber.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("No Parking Space Number specified");
            errorAlert.setContentText("Please enter a Parking Space Number to add");
            errorAlert.showAndWait();
		}
		else {
			int a = 0;
			for(int i = 0; i < parkingSpaceNumber.getText().length(); i++) {
				if(!checker.contains(parkingSpaceNumber.getText().charAt(i))) {
					a = 1;
					i = parkingSpaceNumber.getText().length();
					Alert errorAlert = new Alert(Alert.AlertType.ERROR);
		            errorAlert.setHeaderText("Invalid Parking Space specified");
		            errorAlert.setContentText("Please enter a valid Parking Space Number to add");
		            errorAlert.showAndWait();
				}
			}
			if(a == 0) {
				int n = Integer.parseInt(parkingSpaceNumber.getText());
				if(n == 0) {
					Alert errorAlert = new Alert(Alert.AlertType.ERROR);
		            errorAlert.setHeaderText("Invalid Parking Space specified");
		            errorAlert.setContentText("Please enter a valid Parking Space Number to add");
		            errorAlert.showAndWait();
				}
				else if(n != 0){
					MaintainParkingSpace space = new MaintainParkingSpace(parkingSpaceNumber.getText());
					if(space.already) {
						Alert errorAlert = new Alert(Alert.AlertType.ERROR);
			            errorAlert.setHeaderText("Parking Space already exists");
			            errorAlert.setContentText("Please enter a valid Parking Space Number to add");
			            errorAlert.showAndWait();
					}
					else {
						parkingSpaceNumber.setText("");
						Alert addAlert = new Alert(Alert.AlertType.INFORMATION);
						addAlert.setHeaderText("Parking Space added");
						addAlert.setContentText("Please hit the Back button if you wish to go back to the previous page or add another Parking Space");
						addAlert.showAndWait();
					}
				}
//				else {
//					parkingSpacesAdded.add("Parking " + parkingSpaceNumber.getText());
//					parkingSpaceNumber.setText("");
//					Alert addAlert = new Alert(Alert.AlertType.INFORMATION);
//					addAlert.setHeaderText("Parking Space added");
//					addAlert.setContentText("Please hit the Back button if you wish to go back to the previous page or add another Parking Space");
//					addAlert.showAndWait();
//				}
			}
		}
	}
}
