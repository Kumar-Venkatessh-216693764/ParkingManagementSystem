package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LoginController implements Initializable {
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		//makeFade();
		
	}
	
	@FXML
	private Button customer;
	
	@FXML
	private Button authority;
	
	@FXML
	private Button admin;
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	public void CustomerLoginAction() {
		makeFadeOutCustomer();
	}
	
	public void AuthorityLoginAction() {
		makeFadeOutAuthority();
	}

	public void AdminLoginAction() {
		makeFadeOutAdmin();
	}
	
	private void makeFadeOutCustomer() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadCustomerScene());
		fadeTransition.play();
	}
	
	private void makeFadeOutAuthority() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadAuthorityScene());
		fadeTransition.play();
	}
	
	private void makeFadeOutAdmin() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadAdminScene());
		fadeTransition.play();
	}
	
	private void loadCustomerScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("CustomerLogin.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			CustomerLoginController controller = loader.getController();
//			controller.initData(textArea2, textField2, this.fileContent, this.timeSignature, this.tempo, this.save);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private void loadAuthorityScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("AuthorityLogin.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			AuthorityLoginController controller = loader.getController();
//			controller.initData(textArea2, textField2, this.fileContent, this.timeSignature, this.tempo, this.save);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	private void loadAdminScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("AdminLogin.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			AdminLoginController controller = loader.getController();
//			controller.initData(textArea2, textField2, this.fileContent, this.timeSignature, this.tempo, this.save);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
