package application;

import java.net.URL;

import nonGUI.MaintainParkingSpace;

import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class AuthorityManageParkingController implements Initializable {
	
	ArrayList<String> parkingSpacesAdded = new ArrayList<String>();
	Boolean ok = false;
	String email;
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		makeFade();
		MaintainParkingSpace space = new MaintainParkingSpace();
		for(int i = 1; i < space.parkinglist.size(); i++) {
			list.getItems().add("Parking " + space.parkinglist.get(i));
		}
	}
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	@FXML
	private Button back;
	
	@FXML
	private Button add;
	
	@FXML
	private Button remove;
	
	@FXML
	private Button view;
	
	@FXML
	private ListView list;
	
	public void initData(String user) {
		email = user;
	}
	
	public void BackAction() {
		ButtonType YES = new ButtonType("Yes");
		ButtonType NO = new ButtonType("No");
		AlertType type = AlertType.WARNING; 
		Alert alert = new Alert(type, "Are you sure you want to go back? Any unsaved changes will be lost", YES, NO);
		alert.setHeaderText("Confirmation");
		alert.getDialogPane();
		alert.showAndWait().ifPresent(response ->{
			if(response == YES) {
				makeFadeOutBack();
			}
			if(response == NO) {
				
			}
			
		});;
	}
	
	private void makeFadeOutBack() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadBackScene());
		fadeTransition.play();
	}
	
	private void loadBackScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("AuthoritySignedIn.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			AuthoritySignedInController controller = loader.getController();
			controller.initData(email);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void AddAction() {
//		for(int i = 0; i < parkingSpacesAdded.size(); i++) {
//			parkingSpacesAdded.remove(i);
//		}
//		for(int j = 0; j < list.getItems().size(); j++) {
//			parkingSpacesAdded.add(list.getItems().get(j).toString());
//		}
		makeFadeOutAdd();
	}
	
	private void makeFadeOutAdd() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadAddScene());
		fadeTransition.play();
	}
	
	private void loadAddScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("AuthorityAddParking.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			AuthorityAddParkingController controller = loader.getController();
			controller.initData(email);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void RemoveAction() {
		if(list.getSelectionModel().isEmpty()) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("No Parking Space chosen");
            errorAlert.setContentText("Please choose a parking space from the list to remove");
            errorAlert.showAndWait();
		}
		else if(list.getSelectionModel().getSelectedItems().size() > 1) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Multiple Parking Spaces chosen");
            errorAlert.setContentText("Please choose only 1 parking space from the list to remove");
            errorAlert.showAndWait();
		}
		else {
			int i = list.getSelectionModel().getSelectedIndex();
			MaintainParkingSpace remove = new MaintainParkingSpace(list.getItems().get(i).toString(), "");
			if(remove.removed) {
				list.getItems().remove(i);
				Alert infoAlert = new Alert(Alert.AlertType.INFORMATION);
				infoAlert.setHeaderText("Parking Space removed");
				infoAlert.setContentText("Please proceed to perform other actions");
				infoAlert.showAndWait();
			}
			else if(remove.occupied) {
				Alert errorAlert = new Alert(Alert.AlertType.ERROR);
	            errorAlert.setHeaderText("Parking Space occupied");
	            errorAlert.setContentText("Please choose a parking space that is unoccupied to remove");
	            errorAlert.showAndWait();
			}
		}
	}

	public void ViewAction() {
		if(list.getSelectionModel().isEmpty()) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("No Parking Space chosen");
            errorAlert.setContentText("Please choose a parking space from the list to view information");
            errorAlert.showAndWait();
		}
		else if(list.getSelectionModel().getSelectedItems().size() > 1) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Multiple Parking Spaces chosen");
            errorAlert.setContentText("Please choose only 1 parking space from the list to view information");
            errorAlert.showAndWait();
		}
		else {
			try {
				MaintainParkingSpace space = new MaintainParkingSpace();
				String[] s = list.getSelectionModel().getSelectedItem().toString().split(" ");
				for(int i = 1; i < space.parkinglist.size(); i++) {
					if(space.parkinglist.get(i).equals(s[1]) && space.occupancylist.get(i).equals("occupied")) {
						ok = true;
					}
				}
				if(ok) {
					FXMLLoader loader = new FXMLLoader();
					loader.setLocation(getClass().getResource("AuthorityGrantCancel.fxml"));
					Parent secondView = loader.load();
					Scene newScene = new Scene(secondView);
					AuthorityGrantCancelController controller = loader.getController();
					controller.initData(parkingSpacesAdded, list.getSelectionModel().getSelectedItem().toString(), email);
					Stage curStage = (Stage) rootPane.getScene().getWindow();
					curStage.setScene(newScene);
					curStage.show();
				}
				else {
					Alert errorAlert = new Alert(Alert.AlertType.ERROR);
		            errorAlert.setHeaderText("Parking Space unoccupied");
		            errorAlert.setContentText("Please choose an occupied parking space to Grant or Cancel request");
		            errorAlert.showAndWait();
				}
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
}
