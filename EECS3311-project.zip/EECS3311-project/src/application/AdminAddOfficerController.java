package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import nonGUI.MaintainAdminLogin;

public class AdminAddOfficerController implements Initializable {
	
	String officerID;
	String email2;
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		makeFade();
		
	}
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	@FXML
	private Button back;
	
	@FXML
	private Button add;
	
	@FXML
	private TextField firstName;
	
	@FXML
	private TextField lastName;
	
	@FXML
	private TextField email;
	
	@FXML
	private TextField password;
	
	public void initData(String user) {
		email2 = user;
	}
	
	public void BackAction() {
		makeFadeOutBack();
	}
	
	private void makeFadeOutBack() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadBackScene());
		fadeTransition.play();
	}
	
	private void loadBackScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("AdminSignedIn.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			AdminSignedInController controller = loader.getController();
			controller.initData(email2);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void AddOfficerAction() {
		if(firstName.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("First Name left blank");
            errorAlert.setContentText("Please enter all the details");
            errorAlert.showAndWait();
		}
		else if(lastName.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Last Name left blank");
            errorAlert.setContentText("Please enter all the details");
            errorAlert.showAndWait();
		}
		else if(email.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Email left blank");
            errorAlert.setContentText("Please enter all the details");
            errorAlert.showAndWait();
		}
		else if(password.getText().equals("")) {
			Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Password left blank");
            errorAlert.setContentText("Please enter all your details");
            errorAlert.showAndWait();
		}
		else {
			MaintainAdminLogin login = new MaintainAdminLogin(firstName.getText(), lastName.getText(), "", email.getText(), password.getText());
			if(login.add) {
				firstName.setText("");
				lastName.setText("");
				email.setText("");
				password.setText("");
				Alert infoAlert = new Alert(Alert.AlertType.INFORMATION);
				infoAlert.setHeaderText("Officer successfully added");
				infoAlert.setContentText("The new OfficerID for the added Officer is " + officerID + "\n"
						+ "Add more officers by entering new details or hit the Back button to go back to the previous page");
				infoAlert.showAndWait();
			}
			else {
				Alert errorAlert = new Alert(Alert.AlertType.ERROR);
	            errorAlert.setHeaderText("Incorrect Login Credentials");
	            errorAlert.setContentText("Please recheck the information entered. The entered Officer info already exists in the system.");
	            errorAlert.showAndWait();
			}
		}
	}
}
