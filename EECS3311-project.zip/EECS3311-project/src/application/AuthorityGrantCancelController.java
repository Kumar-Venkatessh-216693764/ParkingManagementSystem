package application;

import java.net.URL;

import nonGUI.MaintainCustomerBooking;

import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class AuthorityGrantCancelController implements Initializable {
	
	ArrayList<String> parkingSpacesAdded = new ArrayList<String>();
	String bookingInfo;
	int a = 0;
	int b = 0;
	String email;
	
	@FXML
	private AnchorPane rootPane;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		makeFade();
		booking.setEditable(false);
	}
	
	private void makeFade() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(0);
		fadeTransition.setToValue(1);
	
		fadeTransition.play();
		
	}
	
	@FXML
	private Button back;
	
	@FXML
	private Button grant;
	
	@FXML
	private Button cancel;
	
	@FXML
	private TextField booking;
	
	public void initData(ArrayList<String> list2, String info, String email2) {
		parkingSpacesAdded = list2;
		bookingInfo = info;
		booking.setText(bookingInfo);
		email = email2;
	}
	
	public void BackAction() {
		if(a == 0 && b == 0) {
			ButtonType YES = new ButtonType("Yes");
			ButtonType NO = new ButtonType("No");
			AlertType type = AlertType.WARNING; 
			Alert alert = new Alert(type, "Are you sure you want to go back? Any unsaved changes will be lost", YES, NO);
			alert.setHeaderText("Confirmation");
			alert.getDialogPane();
			alert.showAndWait().ifPresent(response ->{
				if(response == YES) {
					makeFadeOutBack();
				}
				if(response == NO) {
					
				}
				
			});;
		}
		else {
			makeFadeOutBack();
		}
	}
	
	private void makeFadeOutBack() {
		FadeTransition fadeTransition = new FadeTransition();
		fadeTransition.setDuration(Duration.millis(500));
		fadeTransition.setNode(rootPane);
		fadeTransition.setFromValue(1);
		fadeTransition.setToValue(0);
		fadeTransition.setOnFinished(event -> loadBackScene());
		fadeTransition.play();
	}
	
	private void loadBackScene() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("AuthorityManageParking.fxml"));
			Parent secondView = loader.load();
			Scene newScene = new Scene(secondView);
			AuthorityManageParkingController controller = loader.getController();
			controller.initData(email);
			Stage curStage = (Stage) rootPane.getScene().getWindow();
			curStage.setScene(newScene);
			curStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void GrantAction() {
		if(b == 1) {
			Alert grantAlert = new Alert(Alert.AlertType.INFORMATION);
			grantAlert.setHeaderText("Parking Space Request has already been Cancelled");
			grantAlert.setContentText("Please hit the Back button to go back to the previous page");
			grantAlert.showAndWait();
		}
		if(a == 1) {
			Alert grantAlert = new Alert(Alert.AlertType.INFORMATION);
			grantAlert.setHeaderText("Parking Space Request has already been Granted");
			grantAlert.setContentText("Please hit the Back button to go back to the previous page");
			grantAlert.showAndWait();
		}
		else {
			a = 1;
			String[] space = bookingInfo.split(" ");
			MaintainCustomerBooking grant = new MaintainCustomerBooking(space[1]);
			if(grant.grant) {
				Alert grantAlert = new Alert(Alert.AlertType.INFORMATION);
				grantAlert.setHeaderText("Parking Space Request has been Granted");
				grantAlert.setContentText("Please hit the Back button to go back to the previous page");
				grantAlert.showAndWait();
			}
			else {
				Alert grantAlert = new Alert(Alert.AlertType.INFORMATION);
				grantAlert.setHeaderText("Parking Space Request has already been Granted");
				grantAlert.setContentText("Please hit the Back button to go back to the previous page");
				grantAlert.showAndWait();
			}
		}
	}
	
	public void CancelAction() {
		if(a == 1) {
			Alert grantAlert = new Alert(Alert.AlertType.INFORMATION);
			grantAlert.setHeaderText("Parking Space Request has been Granted");
			grantAlert.setContentText("Please hit the Back button to go back to the previous page");
			grantAlert.showAndWait();
		}
		if(b == 1) {
			Alert grantAlert = new Alert(Alert.AlertType.INFORMATION);
			grantAlert.setHeaderText("Parking Space Request has already been Cancelled");
			grantAlert.setContentText("Please hit the Back button to go back to the previous page");
			grantAlert.showAndWait();
		}
		else {
			b = 1;
			a = 1;
			String[] space = bookingInfo.split(" ");
			MaintainCustomerBooking cancel = new MaintainCustomerBooking(space[1], "");
			if(cancel.cancel) {
				Alert cancelAlert = new Alert(Alert.AlertType.INFORMATION);
				cancelAlert.setHeaderText("Parking Space Request has been Cancelled");
				cancelAlert.setContentText("Please hit the Back button to go back to the previous page");
				cancelAlert.showAndWait();	
			}
			else {
				Alert grantAlert = new Alert(Alert.AlertType.INFORMATION);
				grantAlert.setHeaderText("Parking Space Request has already been Cancelled");
				grantAlert.setContentText("Please hit the Back button to go back to the previous page");
				grantAlert.showAndWait();
			}
		}
	}
}
