package nonGUI;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class MaintainParkingSpace {
	public ArrayList<String> parkinglist = new ArrayList<String>();
	public ArrayList<String> occupancylist = new ArrayList<String>();
	
	public ArrayList<String> parkinglist2 = new ArrayList<String>();
	public ArrayList<String> occupancylist2 = new ArrayList<String>();
	
	public String parkingSpace;
	public Boolean already = false;
	public Boolean occupied = false;
	public Boolean removed = false;
	
	public MaintainParkingSpace(String parkingSpace2) {
		this.parkingSpace = parkingSpace2;
		readDBAdd();
	}
	
	public MaintainParkingSpace() {
		readDB();
	}
	
	public MaintainParkingSpace(String parkingSpace2, String s) {
		String[] list = parkingSpace2.split(" ");
		this.parkingSpace = list[1];
		readDBRemove();
	}
	
	public MaintainParkingSpace(String s1, String s2, String s3) {
		readDBPaid();
	}
	
	private void readDBAdd() {
		parkinglist = new ArrayList<String>();
		occupancylist = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/ParkingSpaceNumbers");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						parkinglist.add(words[i]);
					}
					else if(i == 1) {
						occupancylist.add(words[i]);
					}
				}
			}
			br.close();
			for(int i = 0; i < parkinglist.size(); i++) {
				if(parkinglist.get(i).equals(this.parkingSpace)) {
					this.already = true;
				}
			}
			if(!this.already) {
				writeDBAdd();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void writeDBAdd() {
		File login = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/ParkingSpaceNumbers");
		try {
			BufferedWriter bw = new BufferedWriter( new FileWriter(login));
			if(this.parkingSpace != null) {
				if(!parkinglist.isEmpty()) {
					for(int i = 0; i < parkinglist.size(); i++) {
						bw.write(parkinglist.get(i) + "," + occupancylist.get(i) + "\n");
					}
					bw.write(this.parkingSpace + "," + "unoccupied" + "\n");
				}
			}
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void readDB() {
		parkinglist = new ArrayList<String>();
		occupancylist = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/ParkingSpaceNumbers");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						parkinglist.add(words[i]);
					}
					else if(i == 1) {
						occupancylist.add(words[i]);
					}
				}
			}
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void readDBRemove() {
		parkinglist = new ArrayList<String>();
		occupancylist = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/ParkingSpaceNumbers");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						parkinglist.add(words[i]);
					}
					else if(i == 1) {
						occupancylist.add(words[i]);
					}
				}
			}
			br.close();
			for(int i = 0; i < parkinglist.size(); i++) {
				if(parkinglist.get(i).equals(this.parkingSpace)) {
					if(occupancylist.get(i).equals("occupied")) {
						this.occupied = true;
					}
				}
			}
			if(!this.occupied) {
				writeDBRemove();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void writeDBRemove() {
		File login = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/ParkingSpaceNumbers");
		try {
			BufferedWriter bw = new BufferedWriter( new FileWriter(login));
			if(this.parkingSpace != null) {
				if(!parkinglist.isEmpty()) {
					for(int i = 0; i < parkinglist.size(); i++) {
						if(!this.parkingSpace.equals(parkinglist.get(i))) {
							bw.write(parkinglist.get(i) + "," + occupancylist.get(i) + "\n");
						}
					}
					this.removed = true;
				}
			}
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void readDBPaid() {
		parkinglist = new ArrayList<String>();
		occupancylist = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/ParkingSpaceNumbers");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						parkinglist.add(words[i]);
					}
					else if(i == 1) {
						occupancylist.add(words[i]);
					}
				}
			}
			br.close();
			readDBPaid2();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void readDBPaid2() {
		parkinglist2 = new ArrayList<String>();
		occupancylist2 = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/PaidBookings");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 2) {
						parkinglist2.add(words[i]);
						occupancylist2.add("occupied");
					}
				}
			}
			br.close();
			writeDBPaid();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void writeDBPaid() {
		File login = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/ParkingSpaceNumbers");
		try {
			BufferedWriter bw = new BufferedWriter( new FileWriter(login));
			if(!parkinglist.isEmpty()) {
				for(int i = 0; i < parkinglist.size(); i++) {
					if(!parkinglist2.contains(parkinglist.get(i))){
						bw.write(parkinglist.get(i) + "," + occupancylist.get(i) + "\n");
					}
					else {
						bw.write(parkinglist.get(i) + "," + "occupied" + "\n");
					}
				}
			}
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
