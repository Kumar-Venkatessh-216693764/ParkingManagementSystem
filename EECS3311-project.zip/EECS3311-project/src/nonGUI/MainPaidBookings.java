package nonGUI;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class MainPaidBookings {
	ArrayList<String> firstnamelist = new ArrayList<String>();
	ArrayList<String> lastnamelist = new ArrayList<String>();
	ArrayList<String> parkingSpacelist = new ArrayList<String>();
	ArrayList<String> licencePlatelist = new ArrayList<String>();
	ArrayList<String> hourslist = new ArrayList<String>();
	ArrayList<String> minslist = new ArrayList<String>();
	ArrayList<String> bookingIdlist = new ArrayList<String>();
	ArrayList<String> emaillist = new ArrayList<String>();
	ArrayList<String> expirylist = new ArrayList<String>();
	ArrayList<String> statuslist = new ArrayList<String>();
	ArrayList<String> approvallist = new ArrayList<String>();
	ArrayList<String> paymentlist = new ArrayList<String>();
	
	public ArrayList<String> firstnamelist2 = new ArrayList<String>();
	public ArrayList<String> lastnamelist2 = new ArrayList<String>();
	public ArrayList<String> parkingSpacelist2 = new ArrayList<String>();
	public ArrayList<String> licencePlatelist2 = new ArrayList<String>();
	public ArrayList<String> hourslist2 = new ArrayList<String>();
	public ArrayList<String> minslist2 = new ArrayList<String>();
	public ArrayList<String> bookingIdlist2 = new ArrayList<String>();
	public ArrayList<String> emaillist2 = new ArrayList<String>();
	public ArrayList<String> expirylist2 = new ArrayList<String>();
	ArrayList<String> statuslist2 = new ArrayList<String>();
	ArrayList<String> approvallist2 = new ArrayList<String>();
	ArrayList<String> paymentlist2 = new ArrayList<String>();
	
	ArrayList<String> parkinglist = new ArrayList<String>();	
	ArrayList<String> occupancylist = new ArrayList<String>();
	
	ArrayList<String> parkingSpacesAdded = new ArrayList<String>();
	
	public String firstname;
	public String lastname;
	public String parkingSpace;
	public String licencePlate;
	public String hours;
	public String mins;
	public String bookingId;
	public String email;
	public String expiry;
	public String time;
	public Boolean pay = false;
	
	public MainPaidBookings(String email2) {
		this.email = email2;
		readDBBookings();
	}
	
	public MainPaidBookings(ArrayList<String> list, String email2, String time2) {
		parkingSpacesAdded = list;
		this.email = email2;
		this.time = time2;
		readDBPay();
	}
	
	private void readDBBookings() {
		firstnamelist2 = new ArrayList<String>();
		lastnamelist2 = new ArrayList<String>();
		parkingSpacelist2 = new ArrayList<String>();
		licencePlatelist2 = new ArrayList<String>();
		hourslist2 = new ArrayList<String>();
		minslist2 = new ArrayList<String>();
		bookingIdlist2 = new ArrayList<String>();
		emaillist2 = new ArrayList<String>();
		expirylist2 = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/PaidBookings");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						firstnamelist2.add(words[i]);
					}
					else if(i == 1) {
						lastnamelist2.add(words[i]);
					}
					else if(i == 2) {
						parkingSpacelist2.add(words[i]);
					}
					else if(i == 3) {
						licencePlatelist2.add(words[i]);
					}
					else if(i == 4) {
						hourslist2.add(words[i]);
					}
					else if(i == 5) {
						minslist2.add(words[i]);
					}
					else if(i == 6) {
						bookingIdlist2.add(words[i]);
					}
					else if(i == 7) {
						emaillist2.add(words[i]);
					}
					else if(i == 8) {
						expirylist2.add(words[i]);
					}
				}
			}
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void readDBPay() {
		firstnamelist2 = new ArrayList<String>();
		lastnamelist2 = new ArrayList<String>();
		parkingSpacelist2 = new ArrayList<String>();
		licencePlatelist2 = new ArrayList<String>();
		hourslist2 = new ArrayList<String>();
		minslist2 = new ArrayList<String>();
		bookingIdlist2 = new ArrayList<String>();
		emaillist2 = new ArrayList<String>();
		statuslist2 = new ArrayList<String>();
		approvallist2 = new ArrayList<String>();
		paymentlist2 = new ArrayList<String>();
		
		firstnamelist = new ArrayList<String>();
		lastnamelist = new ArrayList<String>();
		parkingSpacelist = new ArrayList<String>();
		licencePlatelist = new ArrayList<String>();
		hourslist = new ArrayList<String>();
		minslist2 = new ArrayList<String>();
		bookingIdlist = new ArrayList<String>();
		emaillist = new ArrayList<String>();
		statuslist = new ArrayList<String>();
		approvallist = new ArrayList<String>();
		paymentlist = new ArrayList<String>();
		expirylist = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/CustomerBookings");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						firstnamelist2.add(words[i]);
					}
					else if(i == 1) {
						lastnamelist2.add(words[i]);
					}
					else if(i == 2) {
						parkingSpacelist2.add(words[i]);
					}
					else if(i == 3) {
						licencePlatelist2.add(words[i]);
					}
					else if(i == 4) {
						hourslist2.add(words[i]);
					}
					else if(i == 5) {
						minslist2.add(words[i]);
					}
					else if(i == 6) {
						bookingIdlist2.add(words[i]);
					}
					else if(i == 7) {
						emaillist2.add(words[i]);
					}
					else if(i == 8) {
						statuslist2.add(words[i]);
					}
					else if(i == 9) {
						approvallist2.add(words[i]);
					}
					else if(i == 10) {
						paymentlist2.add(words[i]);
					}
				}
			}
			br.close();
			for(int i = 0; i < parkingSpacelist2.size(); i++) {
				if(parkingSpacesAdded.contains(parkingSpacelist2.get(i))) {
					this.firstnamelist.add(firstnamelist2.remove(i));
					this.lastnamelist.add(lastnamelist2.remove(i));
					this.parkingSpacelist.add(parkingSpacelist2.remove(i));
					this.licencePlatelist.add(licencePlatelist2.remove(i));
					this.hourslist.add(hourslist2.remove(i));
					this.minslist.add(minslist2.remove(i));
					this.bookingIdlist.add(bookingIdlist2.remove(i));
					this.emaillist.add(emaillist2.remove(i));
					this.statuslist.add(statuslist2.remove(i));
					this.approvallist.add(approvallist2.remove(i));
					this.paymentlist.add(paymentlist2.remove(i));
					LocalDateTime localTime = LocalDateTime.now();
					DateTimeFormatter curTime = DateTimeFormatter.ofPattern("hh:mm");
					String time = curTime.format(localTime);
					String[] timelist = time.split(":");
					String hr = this.hourslist.get(this.hourslist.size() - 1);
					String min = this.minslist.get(this.minslist.size() - 1);
					int timeHrInt = Integer.parseInt(timelist[0]);
					int timeMinInt = Integer.parseInt(timelist[1]);
					int hrInt = Integer.parseInt(hr);
					int minInt = Integer.parseInt(min);
					int finalHr = timeHrInt + hrInt;
					int finalMin = timeMinInt + minInt;
					this.expirylist.add(finalHr + ":" + finalMin);
				}
			}
			writeDBPay();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void writeDBPay() {
		File login = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/CustomerBookings");
		try {
			BufferedWriter bw = new BufferedWriter( new FileWriter(login));
			if(!parkingSpacesAdded.isEmpty()) {
				if(!firstnamelist2.isEmpty()) {
					for(int i = 0; i < firstnamelist2.size(); i++) {
						if(!parkingSpacelist.contains(parkingSpacelist2.get(i))){
							bw.write(firstnamelist2.get(i) + "," + lastnamelist2.get(i) + "," + parkingSpacelist2.get(i) + "," + licencePlatelist2.get(i) + "," + hourslist2.get(i) + "," + minslist2.get(i) + "," + bookingIdlist2.get(i) + "," + emaillist2.get(i) + "," + statuslist2.get(i) + "," + approvallist2.get(i) + "," + paymentlist2.get(i) + "\n");
						}
					}
					this.pay = true;
				}
			}
			bw.close();
			readDBParking();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void readDBParking() {
		parkinglist = new ArrayList<String>();
		occupancylist = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/ParkingSpaceNumbers");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						parkinglist.add(words[i]);
					}
					else if(i == 1) {
						occupancylist.add(words[i]);
					}
				}
			}
			br.close();
			for(int j = 1; j < parkinglist.size(); j++) {
				if(parkingSpacelist.contains(parkinglist.get(j))) {
					occupancylist.set(j, "occupied");
				}
			}
			writeDBParking();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void writeDBParking() {
		File login = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/ParkingSpaceNumbers");
		try {
			BufferedWriter bw = new BufferedWriter( new FileWriter(login));
			if(!occupancylist.isEmpty()) {
				for(int i = 0; i < occupancylist.size(); i++) {
					bw.write(parkinglist.get(i) + "," + occupancylist.get(i) + "\n");
				}
			}
			bw.close();
			readDBPaid();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void readDBPaid() {
		firstnamelist2 = new ArrayList<String>();
		lastnamelist2 = new ArrayList<String>();
		parkingSpacelist2 = new ArrayList<String>();
		licencePlatelist2 = new ArrayList<String>();
		hourslist2 = new ArrayList<String>();
		minslist2 = new ArrayList<String>();
		bookingIdlist2 = new ArrayList<String>();
		emaillist2 = new ArrayList<String>();
		expirylist2 = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/PaidBookings");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						firstnamelist2.add(words[i]);
					}
					else if(i == 1) {
						lastnamelist2.add(words[i]);
					}
					else if(i == 2) {
						parkingSpacelist2.add(words[i]);
					}
					else if(i == 3) {
						licencePlatelist2.add(words[i]);
					}
					else if(i == 4) {
						hourslist2.add(words[i]);
					}
					else if(i == 5) {
						minslist2.add(words[i]);
					}
					else if(i == 6) {
						bookingIdlist2.add(words[i]);
					}
					else if(i == 7) {
						emaillist2.add(words[i]);
					}
					else if(i == 8) {
						expirylist2.add(words[i]);
					}
				}
			}
			br.close();
			writeDBPaid();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void writeDBPaid() {
		File login = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/PaidBookings");
		try {
			BufferedWriter bw = new BufferedWriter( new FileWriter(login));
			if(!firstnamelist2.isEmpty()) {
				for(int i = 0; i < firstnamelist2.size(); i++) {
					bw.write(firstnamelist2.get(i) + "," + lastnamelist2.get(i) + "," + parkingSpacelist2.get(i) + "," + licencePlatelist2.get(i) + "," + hourslist2.get(i) + "," + minslist2.get(i) + "," + bookingIdlist2.get(i) + "," + emaillist2.get(i) + "," + expirylist2.get(i) + "\n");
				}
			}
			if(!firstnamelist.isEmpty()) {
				for(int j = 0; j < firstnamelist.size(); j++) {
					bw.write(firstnamelist.get(j) + "," + lastnamelist.get(j) + "," + parkingSpacelist.get(j) + "," + licencePlatelist.get(j) + "," + hourslist.get(j) + "," + minslist.get(j) + "," + bookingIdlist.get(j) + "," + emaillist.get(j) + "," + expirylist.get(j) + "\n");
				}
			}
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
