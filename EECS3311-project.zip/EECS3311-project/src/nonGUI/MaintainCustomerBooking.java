package nonGUI;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class MaintainCustomerBooking {
	ArrayList<String> firstnamelist = new ArrayList<String>();
	ArrayList<String> lastnamelist = new ArrayList<String>();
	ArrayList<String> parkingSpacelist = new ArrayList<String>();
	ArrayList<String> licencePlatelist = new ArrayList<String>();
	ArrayList<String> hourslist = new ArrayList<String>();
	ArrayList<String> minslist = new ArrayList<String>();
	ArrayList<String> bookingIdlist = new ArrayList<String>();
	ArrayList<String> emaillist = new ArrayList<String>();
	ArrayList<String> statuslist = new ArrayList<String>();
	ArrayList<String> approvallist = new ArrayList<String>();
	ArrayList<String> paymentlist = new ArrayList<String>();
	
	ArrayList<String> firstnamelist2 = new ArrayList<String>();
	ArrayList<String> lastnamelist2 = new ArrayList<String>();
	ArrayList<String> parkingSpacelist2 = new ArrayList<String>();
	ArrayList<String> licencePlatelist2 = new ArrayList<String>();
	ArrayList<String> hourslist2 = new ArrayList<String>();
	ArrayList<String> minslist2 = new ArrayList<String>();
	ArrayList<String> bookingIdlist2 = new ArrayList<String>();
	ArrayList<String> emaillist2 = new ArrayList<String>();
	ArrayList<String> statuslist2 = new ArrayList<String>();
	ArrayList<String> approvallist2 = new ArrayList<String>();
	ArrayList<String> paymentlist2 = new ArrayList<String>();
	
	ArrayList<String> parkinglist = new ArrayList<String>();	
	ArrayList<String> occupancylist = new ArrayList<String>();	
	
	public String firstname;
	public String lastname;
	public String parkingSpace;
	public String licencePlate;
	public String hours;
	public String mins;
	public String bookingId;
	public String email;
	public Boolean duplicate = false;
	public Boolean booked = false;
	public Boolean many = false;
	public int currentId;
	public Boolean remove = false;
	public Boolean change = false;
	public Boolean already = false;
	public Boolean paid = false;
	public Boolean grant = false;
	public Boolean cancel = false;
	int count = 0;
	public Boolean forth = false;
	public Boolean approved = false;
	public Boolean someoneelse = false;
	public Boolean unapproved = false;
	public Boolean notexist = false;
	
	public MaintainCustomerBooking(String firstname2, String lastname2, String parkingSpace2, String licencePlate2, String hours2, String mins2, String email2) {
		this.firstname = firstname2;
		this.lastname = lastname2;
		this.parkingSpace = parkingSpace2;
		this.licencePlate = licencePlate2;
		this.hours = hours2;
		this.mins = mins2;
		this.email = email2;
		readDBBooking();
	}
	
	public MaintainCustomerBooking(String firstname2, String lastname2, String bookingId2, String email2) {
		this.firstname = firstname2;
		this.lastname = lastname2;
		this.bookingId = bookingId2;
		this.email = email2;
		readDBRemove();
	}
	
	public MaintainCustomerBooking(String firstname2, String lastname2, String parkingSpace2, String email2, String s) {
		this.firstname = firstname2;
		this.lastname = lastname2;
		this.parkingSpace = parkingSpace2;
		this.email = email2;
		readDBChange();
	}
	
	public MaintainCustomerBooking(String parkingSpace2) {
		this.parkingSpace = parkingSpace2;
		readDBGrant();
	}
	
	public MaintainCustomerBooking(String parkingSpace2, String s) {
		this.parkingSpace = parkingSpace2;
		readDBCancel();
	}
	
	public MaintainCustomerBooking(String parkingSpace2, String email2, String s) {
		this.parkingSpace = parkingSpace2;
		this.email = email2;
		readDBPay();
	}
	
	private void readDBBooking() {
		count = 0;
		
		parkinglist = new ArrayList<String>();
		occupancylist = new ArrayList<String>();
		
		File booking3 = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/ParkingSpaceNumbers");
		try {
			BufferedReader br3 = new BufferedReader(new FileReader(booking3));
			String str;
			while((str = br3.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						parkinglist.add(words[i]);
					}
					else if(i == 1) {
						occupancylist.add(words[i]);
					}
				}
			}
			br3.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int j = 1; j < parkinglist.size(); j++) {
			if(parkinglist.get(j).equals(this.parkingSpace)) {
				this.forth = true;
			}
		}
		
		if(this.forth) {
		
			firstnamelist2 = new ArrayList<String>();
			lastnamelist2 = new ArrayList<String>();
			parkingSpacelist2 = new ArrayList<String>();
			licencePlatelist2 = new ArrayList<String>();
			hourslist2 = new ArrayList<String>();
			minslist2 = new ArrayList<String>();
			bookingIdlist2 = new ArrayList<String>();
			emaillist2 = new ArrayList<String>();
			statuslist2 = new ArrayList<String>();
			approvallist2 = new ArrayList<String>();
			paymentlist2 = new ArrayList<String>();
			
			File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/CustomerBookings");
			try {
				BufferedReader br = new BufferedReader(new FileReader(booking));
				String str;
				while((str = br.readLine()) != null) {
					String[] words = str.split(",");
					for(int i = 0; i < words.length; i++) {
						if(i == 0) {
							firstnamelist2.add(words[i]);
						}
						else if(i == 1) {
							lastnamelist2.add(words[i]);
						}
						else if(i == 2) {
							parkingSpacelist2.add(words[i]);
						}
						else if(i == 3) {
							licencePlatelist2.add(words[i]);
						}
						else if(i == 4) {
							hourslist2.add(words[i]);
						}
						else if(i == 5) {
							minslist2.add(words[i]);
						}
						else if(i == 6) {
							bookingIdlist2.add(words[i]);
						}
						else if(i == 7) {
							emaillist2.add(words[i]);
						}
						else if(i == 8) {
							statuslist2.add(words[i]);
						}
						else if(i == 9) {
							approvallist2.add(words[i]);
						}
						else if(i == 10) {
							paymentlist2.add(words[i]);
						}
					}
				}
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			firstnamelist = new ArrayList<String>();
			lastnamelist = new ArrayList<String>();
			parkingSpacelist = new ArrayList<String>();
			licencePlatelist = new ArrayList<String>();
			hourslist = new ArrayList<String>();
			minslist = new ArrayList<String>();
			bookingIdlist = new ArrayList<String>();
			emaillist = new ArrayList<String>();
			
			File booking2 = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/PaidBookings");
			try {
				BufferedReader br2 = new BufferedReader(new FileReader(booking2));
				String str;
				while((str = br2.readLine()) != null) {
					String[] words = str.split(",");
					for(int i = 0; i < words.length; i++) {
						if(i == 0) {
							firstnamelist.add(words[i]);
						}
						else if(i == 1) {
							lastnamelist.add(words[i]);
						}
						else if(i == 2) {
							parkingSpacelist.add(words[i]);
						}
						else if(i == 3) {
							licencePlatelist.add(words[i]);
						}
						else if(i == 4) {
							hourslist.add(words[i]);
						}
						else if(i == 5) {
							minslist.add(words[i]);
						}
						else if(i == 6) {
							bookingIdlist.add(words[i]);
						}
						else if(i == 7) {
							emaillist.add(words[i]);
						}
					}
				}
				br2.close();
				for(int j = 0; j < parkingSpacelist2.size(); j++) {
	//				System.out.println(this.email + " " + this.password);
	//				System.out.println(this.emaillist2.get(j) + " " + this.passwordlist2.get(j));
					if(parkingSpacelist2.get(j).equals(this.parkingSpace)) {
						this.duplicate = true;
					}
				}
				for(int l = 0; l < parkingSpacelist.size(); l++) {
	//				System.out.println(this.email + " " + this.password);
	//				System.out.println(this.emaillist2.get(j) + " " + this.passwordlist2.get(j));
					if(parkingSpacelist.get(l).equals(this.parkingSpace)) {
						this.duplicate = true;
					}
				}
				for(int k = 0; k < emaillist2.size(); k++) {
	//				System.out.println(this.email + " " + this.password);
	//				System.out.println(this.emaillist2.get(j) + " " + this.passwordlist2.get(j));
					if(emaillist2.get(k).equals(this.email)) {
						count ++;
					}
				}
				for(int m = 0; m < emaillist2.size(); m++) {
	//				System.out.println(this.email + " " + this.password);
	//				System.out.println(this.emaillist2.get(j) + " " + this.passwordlist2.get(j));
					if(emaillist2.get(m).equals(this.email)) {
						count ++;
					}
				}
				if(count >= 3) {
					this.many = true;
				}
				if(!this.duplicate && !this.many) {
					writeDBBooking();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	
	private void writeDBBooking() {
		File login = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/CustomerBookings");
		try {
			BufferedWriter bw = new BufferedWriter( new FileWriter(login));
			if(this.email != null) {
				if(!firstnamelist2.isEmpty()) {
					for(int i = 0; i < firstnamelist2.size(); i++) {
						bw.write(firstnamelist2.get(i) + "," + lastnamelist2.get(i) + "," + parkingSpacelist2.get(i) + "," + licencePlatelist2.get(i) + "," + hourslist2.get(i) + "," + minslist2.get(i) + "," + bookingIdlist2.get(i) + "," + emaillist2.get(i) + "," + statuslist2.get(i) + "," + approvallist2.get(i) + "," + paymentlist2.get(i) + "\n");
					}
					this.currentId = firstnamelist2.size();
					bw.write(this.firstname + "," + this.lastname + "," + this.parkingSpace + "," + this.licencePlate + "," + this.hours + "," + this.mins + "," + firstnamelist2.size() + "," + this.email + "," + "unpaid" + "," + "ungranted" + "," + "unpaid" + "\n");
					this.booked = true;
				}
			}
			bw.close();
			readDBParking();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void readDBRemove() {
		firstnamelist2 = new ArrayList<String>();
		lastnamelist2 = new ArrayList<String>();
		parkingSpacelist2 = new ArrayList<String>();
		licencePlatelist2 = new ArrayList<String>();
		hourslist2 = new ArrayList<String>();
		minslist2 = new ArrayList<String>();
		bookingIdlist2 = new ArrayList<String>();
		emaillist2 = new ArrayList<String>();
		statuslist2 = new ArrayList<String>();
		approvallist2 = new ArrayList<String>();
		paymentlist2 = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/CustomerBookings");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						firstnamelist2.add(words[i]);
					}
					else if(i == 1) {
						lastnamelist2.add(words[i]);
					}
					else if(i == 2) {
						parkingSpacelist2.add(words[i]);
					}
					else if(i == 3) {
						licencePlatelist2.add(words[i]);
					}
					else if(i == 4) {
						hourslist2.add(words[i]);
					}
					else if(i == 5) {
						minslist2.add(words[i]);
					}
					else if(i == 6) {
						bookingIdlist2.add(words[i]);
					}
					else if(i == 7) {
						emaillist2.add(words[i]);
					}
					else if(i == 8) {
						statuslist2.add(words[i]);
					}
					else if(i == 9) {
						approvallist2.add(words[i]);
					}
					else if(i == 10) {
						paymentlist2.add(words[i]);
					}
				}
			}
			br.close();
			for(int j = 0; j < firstnamelist2.size(); j++) {
//				System.out.println(this.email + " " + this.password);
//				System.out.println(this.emaillist2.get(j) + " " + this.passwordlist2.get(j));
				if(bookingIdlist2.get(j).equals(this.bookingId) && firstnamelist2.get(j).equals(this.firstname) && lastnamelist2.get(j).equals(this.lastname) && emaillist2.get(j).equals(this.email)) {
					this.remove = true;
					writeDBRemove();
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void writeDBRemove() {
		File login = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/CustomerBookings");
		try {
			BufferedWriter bw = new BufferedWriter( new FileWriter(login));
			if(this.bookingId != null) {
				if(!firstnamelist2.isEmpty()) {
					for(int i = 0; i < firstnamelist2.size(); i++) {
						if(!(this.bookingId.equals(bookingIdlist2.get(i)) && this.email.equals(emaillist2.get(i)))){
							bw.write(firstnamelist2.get(i) + "," + lastnamelist2.get(i) + "," + parkingSpacelist2.get(i) + "," + licencePlatelist2.get(i) + "," + hourslist2.get(i) + "," + minslist2.get(i) + "," + bookingIdlist2.get(i) + "," + emaillist2.get(i) + "," + statuslist2.get(i) + "," + approvallist2.get(i) + "," + paymentlist2.get(i) + "\n");
						}
					}
					this.remove = true;
				}
			}
			bw.close();
			readDBParking();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void readDBChange() {
		firstnamelist2 = new ArrayList<String>();
		lastnamelist2 = new ArrayList<String>();
		parkingSpacelist2 = new ArrayList<String>();
		licencePlatelist2 = new ArrayList<String>();
		hourslist2 = new ArrayList<String>();
		minslist2 = new ArrayList<String>();
		bookingIdlist2 = new ArrayList<String>();
		emaillist2 = new ArrayList<String>();
		statuslist2 = new ArrayList<String>();
		approvallist2 = new ArrayList<String>();
		paymentlist2 = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/CustomerBookings");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						firstnamelist2.add(words[i]);
					}
					else if(i == 1) {
						lastnamelist2.add(words[i]);
					}
					else if(i == 2) {
						parkingSpacelist2.add(words[i]);
					}
					else if(i == 3) {
						licencePlatelist2.add(words[i]);
					}
					else if(i == 4) {
						hourslist2.add(words[i]);
					}
					else if(i == 5) {
						minslist2.add(words[i]);
					}
					else if(i == 6) {
						bookingIdlist2.add(words[i]);
					}
					else if(i == 7) {
						emaillist2.add(words[i]);
					}
					else if(i == 8) {
						statuslist2.add(words[i]);
					}
					else if(i == 9) {
						approvallist2.add(words[i]);
					}
					else if(i == 10) {
						paymentlist2.add(words[i]);
					}
				}
			}
			br.close();
			for(int j = 0; j < firstnamelist2.size(); j++) {
//				System.out.println(this.email + " " + this.password);
//				System.out.println(this.emaillist2.get(j) + " " + this.passwordlist2.get(j));
				if(firstnamelist2.get(j).equals(this.firstname) && lastnamelist2.get(j).equals(this.lastname) && parkingSpacelist2.get(j).equals(this.parkingSpace) && emaillist2.get(j).equals(this.email) && statuslist2.get(j).equals("unpaid") && paymentlist2.get(j).equals("paid")) {
					this.change = true;
					this.paid = true;
					writeDBChange();
				}
//				else if(firstnamelist2.get(j).equals(this.firstname) && lastnamelist2.get(j).equals(this.lastname) && parkingSpacelist2.get(j).equals(this.parkingSpace) && emaillist2.get(j).equals(this.email) && statuslist2.get(j).equals("unpaid") && paymentlist2.get(j).equals("unpaid")) {
//					this.paid = false;
//				}
				else if(firstnamelist2.get(j).equals(this.firstname) && lastnamelist2.get(j).equals(this.lastname) && parkingSpacelist2.get(j).equals(this.parkingSpace) && emaillist2.get(j).equals(this.email) && !statuslist2.get(j).equals("unpaid")) {
					this.already = true;
				}
				else if(firstnamelist2.get(j).equals(this.firstname) && lastnamelist2.get(j).equals(this.lastname) && !parkingSpacelist2.get(j).equals(this.parkingSpace) && emaillist2.get(j).equals(this.email) && statuslist2.get(j).equals("unpaid") && paymentlist2.get(j).equals("paid")) {
					this.paid = true;
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void writeDBChange() {
		File login = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/CustomerBookings");
		try {
			BufferedWriter bw = new BufferedWriter( new FileWriter(login));
			if(this.parkingSpace != null) {
				if(!firstnamelist2.isEmpty()) {
					for(int i = 0; i < firstnamelist2.size(); i++) {
						if(!this.email.equals(emaillist2.get(i))){
							bw.write(firstnamelist2.get(i) + "," + lastnamelist2.get(i) + "," + parkingSpacelist2.get(i) + "," + licencePlatelist2.get(i) + "," + hourslist2.get(i) + "," + minslist2.get(i) + "," + bookingIdlist2.get(i) + "," + emaillist2.get(i) + "," + statuslist2.get(i) + "," + approvallist2.get(i) + "," + paymentlist2.get(i) + "\n");
						}
						else if(this.email.equals(emaillist2.get(i))){
							bw.write(firstnamelist2.get(i) + "," + lastnamelist2.get(i) + "," + parkingSpacelist2.get(i) + "," + licencePlatelist2.get(i) + "," + hourslist2.get(i) + "," + minslist2.get(i) + "," + bookingIdlist2.get(i) + "," + emaillist2.get(i) + "," + "paid" + "," + approvallist2.get(i) + "," + paymentlist2.get(i) + "\n");
						}
					}
					this.change = true;
				}
			}
			bw.close();
			readDBParking();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void readDBParking() {
		parkinglist = new ArrayList<String>();
		occupancylist = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/ParkingSpaceNumbers");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						parkinglist.add(words[i]);
					}
					else if(i == 1) {
						occupancylist.add(words[i]);
					}
				}
			}
			br.close();
			for(int j = 1; j < parkinglist.size(); j++) {
				if(parkingSpacelist2.contains(parkinglist.get(j)) || parkinglist.get(j).equals(this.parkingSpace)) {
					occupancylist.set(j, "occupied");
				}
				else {
					occupancylist.set(j, "unoccupied");
				}
			}
			writeDBParking();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void writeDBParking() {
		File login = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/ParkingSpaceNumbers");
		try {
			BufferedWriter bw = new BufferedWriter( new FileWriter(login));
			if(!occupancylist.isEmpty()) {
				for(int i = 0; i < occupancylist.size(); i++) {
					bw.write(parkinglist.get(i) + "," + occupancylist.get(i) + "\n");
				}
			}
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void readDBGrant() {
		firstnamelist2 = new ArrayList<String>();
		lastnamelist2 = new ArrayList<String>();
		parkingSpacelist2 = new ArrayList<String>();
		licencePlatelist2 = new ArrayList<String>();
		hourslist2 = new ArrayList<String>();
		minslist2 = new ArrayList<String>();
		bookingIdlist2 = new ArrayList<String>();
		emaillist2 = new ArrayList<String>();
		statuslist2 = new ArrayList<String>();
		approvallist2 = new ArrayList<String>();
		paymentlist2 = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/CustomerBookings");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						firstnamelist2.add(words[i]);
					}
					else if(i == 1) {
						lastnamelist2.add(words[i]);
					}
					else if(i == 2) {
						parkingSpacelist2.add(words[i]);
					}
					else if(i == 3) {
						licencePlatelist2.add(words[i]);
					}
					else if(i == 4) {
						hourslist2.add(words[i]);
					}
					else if(i == 5) {
						minslist2.add(words[i]);
					}
					else if(i == 6) {
						bookingIdlist2.add(words[i]);
					}
					else if(i == 7) {
						emaillist2.add(words[i]);
					}
					else if(i == 8) {
						statuslist2.add(words[i]);
					}
					else if(i == 9) {
						approvallist2.add(words[i]);
					}
					else if(i == 10) {
						paymentlist2.add(words[i]);
					}
				}
			}
			br.close();
			for(int j = 0; j < firstnamelist2.size(); j++) {
				if(parkingSpacelist2.get(j).equals(this.parkingSpace) && approvallist2.get(j).equals("ungranted")) {
					this.grant = true;
					writeDBGrant();
				}
				else if(parkingSpacelist2.get(j).equals(this.parkingSpace) && approvallist2.get(j).equals("granted")) {
					
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void writeDBGrant() {
		File login = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/CustomerBookings");
		try {
			BufferedWriter bw = new BufferedWriter( new FileWriter(login));
			if(this.parkingSpace != null) {
				if(!firstnamelist2.isEmpty()) {
					for(int i = 0; i < firstnamelist2.size(); i++) {
						if(!this.parkingSpace.equals(parkingSpacelist2.get(i))){
							bw.write(firstnamelist2.get(i) + "," + lastnamelist2.get(i) + "," + parkingSpacelist2.get(i) + "," + licencePlatelist2.get(i) + "," + hourslist2.get(i) + "," + minslist2.get(i) + "," + bookingIdlist2.get(i) + "," + emaillist2.get(i) + "," + statuslist2.get(i) + "," + approvallist2.get(i) + "," + paymentlist2.get(i) + "\n");
						}
						else if(this.parkingSpace.equals(parkingSpacelist2.get(i))){
							bw.write(firstnamelist2.get(i) + "," + lastnamelist2.get(i) + "," + parkingSpacelist2.get(i) + "," + licencePlatelist2.get(i) + "," + hourslist2.get(i) + "," + minslist2.get(i) + "," + bookingIdlist2.get(i) + "," + emaillist2.get(i) + "," + statuslist2.get(i) + "," + "granted" + "," + paymentlist2.get(i) + "\n");
						}
					}
					this.grant = true;
				}
			}
			bw.close();
			readDBParking();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void readDBCancel() {
		firstnamelist2 = new ArrayList<String>();
		lastnamelist2 = new ArrayList<String>();
		parkingSpacelist2 = new ArrayList<String>();
		licencePlatelist2 = new ArrayList<String>();
		hourslist2 = new ArrayList<String>();
		minslist2 = new ArrayList<String>();
		bookingIdlist2 = new ArrayList<String>();
		emaillist2 = new ArrayList<String>();
		statuslist2 = new ArrayList<String>();
		approvallist2 = new ArrayList<String>();
		paymentlist2 = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/CustomerBookings");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						firstnamelist2.add(words[i]);
					}
					else if(i == 1) {
						lastnamelist2.add(words[i]);
					}
					else if(i == 2) {
						parkingSpacelist2.add(words[i]);
					}
					else if(i == 3) {
						licencePlatelist2.add(words[i]);
					}
					else if(i == 4) {
						hourslist2.add(words[i]);
					}
					else if(i == 5) {
						minslist2.add(words[i]);
					}
					else if(i == 6) {
						bookingIdlist2.add(words[i]);
					}
					else if(i == 7) {
						emaillist2.add(words[i]);
					}
					else if(i == 8) {
						statuslist2.add(words[i]);
					}
					else if(i == 9) {
						approvallist2.add(words[i]);
					}
					else if(i == 10) {
						paymentlist2.add(words[i]);
					}
				}
			}
			br.close();
			for(int j = 0; j < firstnamelist2.size(); j++) {
				if(parkingSpacelist2.get(j).equals(this.parkingSpace) && approvallist2.get(j).equals("ungranted")) {
					this.cancel = true;
					writeDBCancel();
				}
				else if(parkingSpacelist2.get(j).equals(this.parkingSpace) && approvallist2.get(j).equals("granted")) {
					
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void writeDBCancel() {
		File login = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/CustomerBookings");
		try {
			BufferedWriter bw = new BufferedWriter( new FileWriter(login));
			if(this.parkingSpace != null) {
				if(!firstnamelist2.isEmpty()) {
					for(int i = 0; i < firstnamelist2.size(); i++) {
						if(!this.parkingSpace.equals(parkingSpacelist2.get(i))){
							bw.write(firstnamelist2.get(i) + "," + lastnamelist2.get(i) + "," + parkingSpacelist2.get(i) + "," + licencePlatelist2.get(i) + "," + hourslist2.get(i) + "," + minslist2.get(i) + "," + bookingIdlist2.get(i) + "," + emaillist2.get(i) + "," + statuslist2.get(i) + "," + approvallist2.get(i) + "," + paymentlist2.get(i) + "\n");
						}
					}
					this.cancel = true;
				}
			}
			bw.close();
			readDBParking();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void readDBPay() {
		firstnamelist2 = new ArrayList<String>();
		lastnamelist2 = new ArrayList<String>();
		parkingSpacelist2 = new ArrayList<String>();
		licencePlatelist2 = new ArrayList<String>();
		hourslist2 = new ArrayList<String>();
		minslist2 = new ArrayList<String>();
		bookingIdlist2 = new ArrayList<String>();
		emaillist2 = new ArrayList<String>();
		statuslist2 = new ArrayList<String>();
		approvallist2 = new ArrayList<String>();
		paymentlist2 = new ArrayList<String>();
		
		File booking = new File("/Users/venkatesshkumar/eecs2311Java15/EECS3311-project/src/nonGUI/CustomerBookings");
		try {
			BufferedReader br = new BufferedReader(new FileReader(booking));
			String str;
			while((str = br.readLine()) != null) {
				String[] words = str.split(",");
				for(int i = 0; i < words.length; i++) {
					if(i == 0) {
						firstnamelist2.add(words[i]);
					}
					else if(i == 1) {
						lastnamelist2.add(words[i]);
					}
					else if(i == 2) {
						parkingSpacelist2.add(words[i]);
					}
					else if(i == 3) {
						licencePlatelist2.add(words[i]);
					}
					else if(i == 4) {
						hourslist2.add(words[i]);
					}
					else if(i == 5) {
						minslist2.add(words[i]);
					}
					else if(i == 6) {
						bookingIdlist2.add(words[i]);
					}
					else if(i == 7) {
						emaillist2.add(words[i]);
					}
					else if(i == 8) {
						statuslist2.add(words[i]);
					}
					else if(i == 9) {
						approvallist2.add(words[i]);
					}
					else if(i == 10) {
						paymentlist2.add(words[i]);
					}
				}
			}
			br.close();
			for(int j = 0; j < firstnamelist2.size(); j++) {
				if(parkingSpacelist2.get(j).equals(this.parkingSpace) && approvallist2.get(j).equals("granted") && emaillist2.get(j).equals(this.email)) {
					this.approved = true;
					this.hours = hourslist2.get(j);
					this.mins = minslist2.get(j);
					writeDBPay();
				}
				else if(parkingSpacelist2.get(j).equals(this.parkingSpace) && !emaillist2.get(j).equals(this.email)) {
					this.someoneelse = true;
				}
				else if(parkingSpacelist2.get(j).equals(this.parkingSpace) && !approvallist2.get(j).equals("granted") && emaillist2.get(j).equals(this.email)) {
					this.unapproved = true;
				}
				else {
					this.notexist = true;
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void writeDBPay() {
		
	}
}
